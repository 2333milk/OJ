/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_QuestionSubmit_ } from './Page_QuestionSubmit_';
export type BaseResponse_Page_QuestionSubmit_ = {
    code?: number;
    data?: Page_QuestionSubmit_;
    message?: string;
};

