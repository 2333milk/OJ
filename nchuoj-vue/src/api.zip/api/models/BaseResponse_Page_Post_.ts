/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_Post_ } from './Page_Post_';
export type BaseResponse_Page_Post_ = {
    code?: number;
    data?: Page_Post_;
    message?: string;
};

