/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type BaseResponse_string_ = {
    code?: number;
    data?: string;
    message?: string;
};

