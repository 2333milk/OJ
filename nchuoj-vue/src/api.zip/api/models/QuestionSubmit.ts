/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type QuestionSubmit = {
    code?: string;
    createTime?: string;
    id?: number;
    judgeInfo?: string;
    language?: string;
    questionId?: number;
    status?: number;
    updateTime?: string;
    userId?: number;
};

