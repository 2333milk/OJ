/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { LoginUserVO } from './LoginUserVO';
export type BaseResponse_LoginUserVO_ = {
    code?: number;
    data?: LoginUserVO;
    message?: string;
};

