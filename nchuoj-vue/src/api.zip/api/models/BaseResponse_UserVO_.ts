/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { UserVO } from './UserVO';
export type BaseResponse_UserVO_ = {
    code?: number;
    data?: UserVO;
    message?: string;
};

